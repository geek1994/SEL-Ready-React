import React, { Component } from "react";
import "./Feedback.css";

class Feedback extends Component {
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">people</i>
                  </div>
                  <h4 className="card-title mt-3">Feedback</h4>
                </div>
                <div className="card-body">
                  <div className="flex flex-wrap mx-3 mt-10 md:mt-20">
                    <div className="w-full md:w-1/2 mb-4">
                      <div className="flex flex-wrap items-center">
                        <div className="w-full md:w-3/12 px-4">
                          <label className="block text-black-100 text-base font-medium text-left mb-1 md:mb-0 pr-4">
                            Name
                          </label>
                        </div>
                        <div className="w-full md:w-9/12 px-4">
                          <input
                            className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                            type="text"
                            placeholder="Teacher Teacher"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="w-full md:w-1/2 mb-4">
                      <div className="flex flex-wrap items-center">
                        <div className="w-full md:w-3/12 px-4">
                          <label className="block text-black-100 text-base font-medium text-left mb-1 md:mb-0 pr-4">
                            Email
                          </label>
                        </div>
                        <div className="w-full md:w-9/12 px-4">
                          <input
                            className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                            type="mail"
                            placeholder="teacher@selready.com"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap mx-3">
                    <div className="w-full md:w-1/2 mb-4">
                      <div className="flex flex-wrap">
                        <div className="w-full md:w-3/12 px-4">
                          <label className="block text-black-100 text-base font-medium text-left mb-1 md:mb-0 pr-4">
                            Feedback
                          </label>
                        </div>
                        <div className="w-full md:w-9/12  px-4">
                          <textarea
                            className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                            id="feedback_area"
                            rows="7"
                          ></textarea>
                        </div>
                      </div>
                    </div>
                    <div className="w-full md:w-1/2  mb-4">
                      <div className="flex flex-wrap items-center">
                        <div className="w-full md:w-3/12 px-4">
                          <label className="block text-black-100 text-base font-medium text-left mb-1 md:mb-0 pr-4">
                            Upload Image
                          </label>
                        </div>
                        <div className="w-full md:w-9/12 px-4">
                          <div className="upload-button-wrapper">
                            <span className="label">Upload File</span>

                            <input
                              type="file"
                              name="upload"
                              id="upload-file"
                              className="upload-box"
                              placeholder="Upload File"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-right mb-4">
                    <button
                      className="shadow bg-red-700 hover:bg-red-800 focus:shadow-outline focus:outline-none text-white font-medium mt-4 py-2 px-4 uppercase rounded"
                      type="button"
                    >
                      Update
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Feedback;
