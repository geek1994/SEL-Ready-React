import React from "react";
import IntlTelInput from "react-intl-tel-input";
import "react-intl-tel-input/dist/main.css";
import "./PhoneInputNumber.css";

const PhoneInputNumber = () => {
  return (
    <IntlTelInput
      containerClassName="intl-tel-input w-full focus:outline-none flagcc"
      inputClassName="form-control w-full focus:outline-none border-gray-300 border py-2 rounded"
    />
  );
};

export default PhoneInputNumber;
