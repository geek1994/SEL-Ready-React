import React, { Component } from "react";
import "./Gallery.css";
import { Link } from "react-router-dom";

class Gallery extends Component {
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">people</i>
                  </div>
                  <h4 className="card-title mt-12 md:mt-3 mb-4 md:mb-0">
                    Gallery
                  </h4>
                </div>
                <div className="card-body">
                  <div id="gallery" className="text-center py-10">
                    <div id="image-gallery">
                      <div className="w-full">
                        <p>You have not uploaded any media.</p>
                        <Link
                          to="/profile"
                          className="gallery_btn inline-block bg-red-700 text-white active:bg-red-800 uppercase text-md px-4 py-2 mb-8 rounded shadow hover:shadow-lg outline-none focus:outline-none mt-4"
                        >
                          Go to upload Media
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Gallery;
