import React, { Component } from "react";
import "./Chat.css";
import { Link } from "react-router-dom";
import chatimg from "../../../assets/images/chatbg.jpg";

class Chat extends Component {
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="mx-auto flex md:flex-row flex-col items-center">
              <div className="flex w-full flex-wrap">
                <div className="md:w-full lg:w-1/3 w-full">
                  <div className="sideChat h-full shadow-md">
                    <div className="p-3 border-b border-gray-300">
                      <div className="chatUser flex items-center relative">
                        <img
                          src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                          alt=""
                          className="w-12 rounded-full"
                        />
                        <h2 className="font-medium pl-5">Miguel Cantu</h2>
                        <Link to="#" className="absolute right-0 ">
                          <i
                            className="fa fa-refresh fa-2x refresh-btn"
                            aria-hidden="true"
                          ></i>
                        </Link>
                      </div>
                    </div>
                    <div className="p-4">
                      <label className="block">
                        <input
                          type="email"
                          className="form-input mt-1 text-sm block w-full focus:shadow-none"
                          placeholder="Search"
                        />
                      </label>
                    </div>
                    <div className="p-3 graycolor">
                      <Link to="#">
                        <div className="chatUser flex justify-between">
                          <div className="flex items-start relative">
                            <img
                              src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                              alt=""
                              className="w-12 rounded-full"
                            />
                            <h2 className="font-medium pl-5">
                              Abc <br />{" "}
                              <small className="text-gray-600 font-medium">
                                Hello
                              </small>
                            </h2>
                          </div>
                          <small className="text-gray-600 font-medium w-40 text-right">
                            2:21 PM
                          </small>
                        </div>
                      </Link>
                    </div>
                    <div className="p-3 border-b border-gray-200">
                      <Link to="#">
                        <div className="chatUser flex justify-between">
                          <div className="flex items-start relative">
                            <img
                              src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                              alt=""
                              className="w-12 rounded-full"
                            />
                            <h2 className="font-medium pl-5">
                              Abc <br />{" "}
                              <small className="text-gray-600 font-medium">
                                Hello
                              </small>
                            </h2>
                          </div>
                          <small className="text-gray-600 font-medium w-40 text-right">
                            2:21 PM
                          </small>
                        </div>
                      </Link>
                    </div>
                    <div className="p-3">
                      <Link to="#">
                        <div className="chatUser flex justify-between">
                          <div className="flex items-start relative">
                            <img
                              src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                              alt=""
                              className="w-12 rounded-full"
                            />
                            <h2 className="font-medium pl-5">
                              Abc <br />{" "}
                              <small className="text-gray-600 font-medium">
                                Hello
                              </small>
                            </h2>
                          </div>
                          <small className="text-gray-600 font-medium w-40 text-right">
                            2:21 PM
                          </small>
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
                <div className="md:w-full lg:w-2/3 w-full">
                  <div
                    className="sideChat1 h-full shadow-md"
                    style={{ backgroundImage: `url(${chatimg})` }}
                  >
                    <div className="p-3 border-b border-gray-300 bg-white">
                      <div className="chatUser flex items-center relative">
                        <img
                          src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                          alt=""
                          className="w-12 rounded-full"
                        />
                        <h2 className="font-medium pl-5">Abc</h2>
                      </div>
                    </div>
                    <div className="chat-messages">
                      <div className="p-3">
                        <div className="datechat text-gray-600 relative text-sm text-center">
                          <p className="date-line">08/17/2020</p>
                        </div>
                        <div className="chatUser flex justify-between mt-2">
                          <div className="flex items-start relative">
                            <img
                              src="https://demo.selready.com/uploads/profile_image_1597397178.jpeg"
                              alt=""
                              className="w-12 rounded-full"
                            />
                            <h2 className="font-normal pl-3 flex flex-col">
                              <div>
                                Teacher
                                <span
                                  className="text-xs ml-2 text-white py-1 px-2 rounded-sm"
                                  style={{ backgroundColor: "#00bcd4" }}
                                >
                                  2:20PM
                                </span>
                              </div>
                              <small className="text-gray-700 font-medium message-partner-text">
                                orem ipsum, or lipsum as it is sometimes known,
                                is dummy text used in laying out print, graphic
                                or web designs. The passage is attributed to an
                                unknown typesetter in the 15th century who is
                                thought to ha
                              </small>
                            </h2>
                          </div>
                        </div>
                      </div>
                      <div className="p-3">
                        <div className="chatUser flex justify-end mt-2">
                          <div className="flex items-start relative">
                            <h2 className="font-normal flex flex-col">
                              <div className="text-right">
                                <span className="text-xs bg-white p-1">
                                  2:20PM
                                </span>
                              </div>
                              <small className=" font-medium message-box">
                                Hi
                              </small>
                            </h2>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex">
                      <div className="upload-btn-wrapper border-gray-300 ">
                        <input
                          type="file"
                          name="myfile"
                          className="chat_input-file cursor-pointer"
                        />
                        <i className="fa fa-paperclip py-6 px-5 pr-4 font-22 bg-white border border-gray-300 "></i>
                      </div>
                      <textarea
                        placeholder="Test1234"
                        className="resize placeholder-opacity-100 border border-gray-300 p-2 px-3 text-sm w-full focus:outline-none"
                      ></textarea>
                      <button className="transition duration-300 text-sm ease-in-out active:outline-none bgColor hover:opacity-75 active:rounded-none focus:outline-none text-white font-normal py-2 shadow-lg  px-3 mr-2">
                        <i className="material-icons">send</i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Chat;
