import React, { Component } from "react";
import "./Calendar.css";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";

class Calendar extends Component {
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-body calender-page">
                  <FullCalendar
                    plugins={[dayGridPlugin]}
                    initialView="dayGridMonth"
                    weekends={true}
                    events={[
                      { title: "event 1", date: "2020-08-01" },
                      { title: "event 2", date: "2020-08-02" },
                    ]}
                  />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Calendar;
