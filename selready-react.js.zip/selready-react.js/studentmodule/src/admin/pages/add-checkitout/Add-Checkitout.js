import React, { Component } from "react";
import "./Add-Checkitout.css";
import { Link } from "react-router-dom";

class AddCheckitout extends Component {
  constructor() {
    super();
    this.state = {
      video: false,
      image: false,
      url: false,
    };
  }

  videofn() {
    this.setState({
      video: !this.state.video,
      image: false,
      url: false,
    });
  }

  imagefn() {
    this.setState({
      image: !this.state.image,
      video: false,
      url: false,
    });
  }

  urlfn() {
    this.setState({
      url: !this.state.url,
      video: false,
      image: false,
    });
  }

  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">people</i>
                  </div>
                  <h4 className="card-title mt-12 md:mt-3 mb-4 md:mb-0">
                    Check It Out
                  </h4>
                  <Link
                    id="addbtn"
                    className="add_user_btn btn-rose inline-block"
                    to="/checkitout"
                  >
                    Back
                  </Link>
                </div>

                <div className="card-body">
                  <form method="GET" className="mt-4">
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Title [English]
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12">
                            <input
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              type="text"
                              placeholder="Enter title in English"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Titulo
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12">
                            <input
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              type="text"
                              placeholder="Entra su Titulo"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 md:mt-4">
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Description [English]
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12">
                            <textarea
                              type="text"
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              placeholder="Enter description in English"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Descripcion
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12">
                            <textarea
                              type="text"
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              placeholder="Entra su Descripcion"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 md:mt-4">
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Author
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12">
                            <select className=" block w-full bg-white border border-gray-400 text-gray-700 py-2 px-4 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                              <option>BIll Thomas</option>
                              <option>Cam Stuart</option>
                              <option>Cameron Stuart</option>
                              <option>Michael Russell</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4 md:mt-4">
                      <div className="col-span-12 md:col-span-12">
                        <div className="grid grid-cols-12 mb-2 px-4">
                          <div className="col-span-12 md:col-span-12">
                            <label className="block text-black-100 font-medium text-left mb-2 pr-4 bmd-label">
                              Upload Image or Video
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-12 mt-2">
                            <label className="form-check-label font-semibold text-gray-600">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="exampleRadios"
                                id="imageRadio"
                                onClick={() => this.imagefn()}
                              />
                              &nbsp; Upload Image
                              <span className="circle">
                                <span className="check"></span>
                              </span>
                            </label>
                            <label className="form-check-label ml-6  font-semibold text-gray-600">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="exampleRadios"
                                id="imageRadio"
                                onClick={() => this.videofn()}
                              />
                              &nbsp; Upload Video
                              <span className="circle">
                                <span className="check"></span>
                              </span>
                            </label>
                            <label className="form-check-label  ml-6  font-semibold text-gray-600">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="exampleRadios"
                                id="imageRadio"
                                onClick={() => this.urlfn()}
                              />
                              &nbsp; URL
                              <span className="circle">
                                <span className="check"></span>
                              </span>
                            </label>
                            {this.state.image ? (
                              <>
                                <div className="Section_vidoe block">
                                  <div className="overflow-hidden relative w-64 mt-4 mb-4">
                                    <button className="bg-red-700 hover:bg-red-800 text-white font-bold py-2 px-4 rounded  inline-flex items-center">
                                      <svg
                                        fill="#FFF"
                                        height="18"
                                        viewBox="0 0 24 24"
                                        width="18"
                                        xmlns="http://www.w3.org/2000/svg"
                                      >
                                        <path d="M0 0h24v24H0z" fill="none" />
                                        <path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" />
                                      </svg>
                                      <span className="ml-2">Select Image</span>
                                    </button>
                                    <input
                                      className="cursor-pointer absolute block opacity-0 top-0 py-1 pin-r pin-t"
                                      type="file"
                                      name=""
                                    />
                                  </div>
                                </div>
                              </>
                            ) : null}
                            {this.state.video ? (
                              <>
                                <div className="Section_image block">
                                  <div className="overflow-hidden relative w-64 mt-4 mb-4">
                                    <button className="bg-red-700 hover:bg-red-800 text-white font-bold py-2 px-4 rounded  inline-flex items-center">
                                      <svg
                                        fill="#FFF"
                                        height="18"
                                        viewBox="0 0 24 24"
                                        width="18"
                                        xmlns="http://www.w3.org/2000/svg"
                                      >
                                        <path d="M0 0h24v24H0z" fill="none" />
                                        <path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z" />
                                      </svg>
                                      <span className="ml-2">Select Video</span>
                                    </button>
                                    <input
                                      className="cursor-pointer absolute block opacity-0 top-0 py-1 pin-r pin-t"
                                      type="file"
                                      name=""
                                    />
                                  </div>
                                </div>
                              </>
                            ) : null}
                            {this.state.url ? (
                              <>
                                <div className="Section_url block mt-5">
                                  <input
                                    type="text"
                                    class="bg-white border border-gray-400 rounded lg:w-1/2 py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                                    placeholder="Enter your Link"
                                    value=""
                                  />
                                </div>
                              </>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right mb-4">
                      <button
                        className="shadow bg-red-700 hover:bg-red-800 focus:shadow-outline focus:outline-none text-white font-medium mt-4 py-2 px-4 uppercase rounded"
                        type="button"
                      >
                        Add
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default AddCheckitout;
