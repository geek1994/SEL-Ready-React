import React, { Component } from "react";
import "./Add-Contest.css";
import { Link } from "react-router-dom";
import DummyIcon from "../../../assets/images/dummy-contest-icon.jpg";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

class AddContest extends Component {
  constructor(props) {
    super(props);
    this.state = {
      startDate: new Date(),
    };
  }
  handleChange = (date) => {
    this.setState({
      startDate: date,
    });
  };
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="w-full w-1/1">
              <div className="card ">
                <div className="card-header card-header-icon card-header-primary">
                  <div className="card-icon">
                    <i className="material-icons">emoji_events</i>
                  </div>
                  <h4 className="card-title mt-12 md:mt-3 mb-5 md:mb-0">
                    Add Contest
                  </h4>
                  <Link
                    id="addbtn"
                    className="add_user_btn btn-rose inline-block modal-open"
                    to="/contests"
                  >
                    Back
                  </Link>
                </div>

                <div className="card-body">
                  <form method="POST">
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6">
                        <div className="grid grid-cols-12 mb-5">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Contest Image
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <div className="picture card-avatar">
                              <div className="edit edit-event-img">
                                <button id="wizardPicturePreview">
                                  <i className="fa fa-pencil fa-lg"></i>
                                </button>
                              </div>
                              <input type="file" id="file" className="" />
                              <img
                                src={DummyIcon}
                                alt={DummyIcon}
                                className="picture-src"
                                id=""
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6 mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Name of Contest
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <input
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              type="text"
                              placeholder="Name of Contest"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6">
                        <div className="col-span-12 md:col-span-6  mb-5">
                          <div className="grid grid-cols-12">
                            <div className="col-span-12 md:col-span-4 px-4">
                              <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                                Select Schools
                              </label>
                            </div>
                            <div className="col-span-12 md:col-span-8 px-4">
                              <select className="appearance-none block w-full bg-white border border-gray-400 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                                <option>Select Type of Institute</option>
                                <option>Middle school</option>
                                <option>School</option>
                                <option>College</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Select Grades
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <select className="appearance-none block w-full bg-white border border-gray-400 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                              <option>Select Grades</option>
                              <option>Grades1</option>
                              <option>Grades2</option>
                              <option>Grades3</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6">
                        <div className="col-span-12 md:col-span-6  mb-5">
                          <div className="grid grid-cols-12">
                            <div className="col-span-12 md:col-span-4 px-4">
                              <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                                Judges Panel
                              </label>
                            </div>
                            <div className="col-span-12 md:col-span-8 px-4">
                              <select className="appearance-none block w-full bg-white border border-gray-400 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500">
                                <option>Select Instructor/Fellow</option>
                                <option>Instructor1</option>
                                <option>Instructor2</option>
                                <option>Instructor3</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Start Date
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <div className="relative datepic">
                              <DatePicker
                                selected={this.state.startDate}
                                onChange={this.handleChange}
                                className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              />
                              <i class="fa fa-calendar" aria-hidden="true"></i>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6">
                        <div className="col-span-12 md:col-span-6  mb-5">
                          <div className="grid grid-cols-12">
                            <div className="col-span-12 md:col-span-4 px-4">
                              <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                                Start End
                              </label>
                            </div>
                            <div className="col-span-12 md:col-span-8 px-4">
                              <div className="relative datepic">
                                <DatePicker
                                  selected={this.state.startDate}
                                  onChange={this.handleChange}
                                  className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                                />
                                <i
                                  class="fa fa-calendar"
                                  aria-hidden="true"
                                ></i>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Summary
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <textarea
                              type="text"
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              placeholder="Summary"
                              rows="5"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Rules
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <textarea
                              type="text"
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              placeholder="List rules for the contest here"
                              rows="5"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-12 gap-4">
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Areas to Judge
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-8 px-4">
                            <textarea
                              type="text"
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              placeholder="List areas to judge here"
                              rows="5"
                            ></textarea>
                          </div>
                        </div>
                      </div>
                      <div className="col-span-12 md:col-span-6  mb-5">
                        <div className="grid grid-cols-12">
                          <div className="col-span-12 md:col-span-4 px-4">
                            <label className="block text-black-100 font-medium text-left mb-1 md:mb-0 pr-4 bmd-label">
                              Important Links
                            </label>
                          </div>
                          <div className="col-span-12 md:col-span-7 px-4">
                            <input
                              className="bg-white border border-gray-400 rounded w-full py-2 px-4 text-gray-700 focus:outline-none focus:bg-white focus:border-gray-800"
                              type="text"
                              placeholder="Add link to contest here"
                            />
                          </div>
                          <div className="col-span-12 md:col-span-1 px-4">
                            <button
                              className="add-links btn btn-rose text-red-700"
                              type="button"
                              id="add_single"
                            >
                              <i className="material-icons">add</i>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right mb-5">
                      <button
                        className="shadow bg-red-700 hover:bg-red-800 focus:shadow-outline focus:outline-none text-white font-medium mt-4 py-2 px-4 uppercase rounded"
                        type="button"
                      >
                        Submit
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default AddContest;
