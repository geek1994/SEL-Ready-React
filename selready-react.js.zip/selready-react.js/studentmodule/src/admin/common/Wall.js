import React, { Component } from "react";
import "./Wall.css";
import ProfileImage from "../../assets/images/profile_image.jpeg";
import { Link } from "react-router-dom";

class Wall extends Component {
  constructor() {
    super();
    this.state = {
      comment: false,
      report: false,
      detail: false,
    };
  }

  commentfn() {
    this.setState({
      comment: !this.state.comment,
      report: false,
      detail: false,
    });
  }

  reportfn1() {
    this.setState({
      report: !this.state.report,
      comment: false,
      detail: false,
    });
  }

  detailfn() {
    this.setState({
      detail: !this.state.detail,
      comment: false,
      report: false,
    });
  }
  render() {
    return (
      <div>
        <main className="content">
          <div className="container-fluid">
            <div className="wall-events">
              <div className="w-full flex flex-wrap">
                <div className="md:w-4/6 w-full">
                  <div className="event-wall-section">
                    <div className="p-4 flex items-center shadow-md border">
                      <div className="w-4/6">
                        <h5 className="text-xl font-semibold text-gray-800">
                          Latest Updates123
                        </h5>
                      </div>
                      <div className="w-4/12">
                        <select
                          name=""
                          className="form-control select-cardtype block w-full bg-white border border-gray-400 text-gray-700 py-2 px-4 pr-4 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                        >
                          <option value="all">All</option>
                          <option value="events">Events</option>
                          <option value="spotlight">Spotlight</option>
                          <option value="checkitout">Check It Out</option>
                          <option value="contest">Contest</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="events_row">
                    <div className="event_col">
                      <div className="event_body border shadow">
                        <span className="event-tag-wall">Event</span>
                        <div className="event_image">
                          <div className="event_date d-flex flex-column align-items-center justify-content-center">
                            <div className="event_day">04</div>
                            <div className="event_month">Aug</div>
                          </div>
                        </div>
                        <div className="section">
                          <div className="event_title mt-30">
                            <h4>Test mohali1</h4>
                          </div>
                          <div className="article border-b">
                            <p className="text1">hello </p>
                          </div>
                          <div className="coment-tag">
                            <div className="flex flex-wrap items-center mt-4">
                              <div className="w-full lg:w-4/12">
                                <span
                                  className="comments event_comments"
                                  onClick={() => this.commentfn()}
                                >
                                  <i
                                    className="fa fa-comment-o"
                                    aria-hidden="true"
                                  ></i>{" "}
                                  <span className="comment_text" id="comments">
                                    Comments (0)
                                  </span>
                                </span>
                              </div>

                              <div className="w-full lg:w-4/12">
                                <span className=" view_details_heading">
                                  <i
                                    className="fa fa-info"
                                    aria-hidden="true"
                                  ></i>
                                  <span
                                    className="view_detail"
                                    onClick={() => this.detailfn()}
                                  >
                                    View Details
                                  </span>
                                </span>
                              </div>
                              <div className="w-full lg:w-4/12 ">
                                <div className="reports-sec">
                                  <span
                                    className="view_details_heading"
                                    onClick={() => this.reportfn1()}
                                  >
                                    <i className="material-icons">
                                      error_outline
                                    </i>{" "}
                                    <span>Report</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            {this.state.comment ? (
                              <>
                                <div className="Section_comment block">
                                  <div className="panel mt-10">
                                    <div className="panel-heading  text-left mb-4 leading-3 text-lg  border-b-1 border-gray-400 text-gray-600">
                                      Comments
                                    </div>
                                    <form id="commentsubmit2checkitout">
                                      <textarea
                                        className="mt-5 block w-full bg-white border border-gray-400 text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                        placeholder="write a comment..."
                                        rows="3"
                                        id="message2checkitout"
                                        name="comment"
                                      ></textarea>
                                      <br /> <br />
                                      <br />
                                      <button
                                        id="addbtn"
                                        className="add_user_btn btn-rose long-btn"
                                      >
                                        POST
                                      </button>
                                    </form>

                                    <div
                                      id="comments-listcheckitout2"
                                      className="mt-10"
                                    >
                                      <hr />
                                      <div className="text-white bg-orange-400 p-4 rounded-sm shadow-xl text-base">
                                        There is no comment yet
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </>
                            ) : null}
                            {this.state.detail ? (
                              <>
                                <div className="Section_comment block">
                                  <div className="panel mt-12">
                                    <div className="panel-heading  text-left mb-4 leading-3 text-xl  border-b-1 border-gray-400 text-black font-semibold">
                                      Description
                                    </div>
                                    <p>
                                      30 minute fat burning home workout for
                                      beginners. Achievable, low impact results.
                                    </p>
                                  </div>
                                </div>
                              </>
                            ) : null}
                            {this.state.report ? (
                              <>
                                <div className="Section_report absolute lg:right-0 mt-2 w-56 border bg-white p-4 rounded-md shadow-lg z-50">
                                  <form id="reportFrm-checkitout-2">
                                    <select
                                      type="text"
                                      className="mt-3 block w-full bg-white border border-gray-400 text-gray-700 py-2 px-2 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                    >
                                      <option>Public Shaming</option>
                                      <option>
                                        Violation of someone's privacy
                                      </option>
                                      <option>Fraud and spam</option>
                                    </select>
                                    <button className="mt-3 bg-red-700 hover:bg-red-900 text-white font-semibold py-2 px-4 rounded">
                                      Submit
                                    </button>
                                  </form>
                                </div>
                              </>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="events_row mt-10">
                    <div className="event_col">
                      <div className="event_body border shadow">
                        <span className="event-tag-wall">Event</span>
                        <div className="event_image">
                          <div className="event_date d-flex flex-column align-items-center justify-content-center">
                            <div className="event_day">04</div>
                            <div className="event_month">Aug</div>
                          </div>
                          <img src={ProfileImage} alt="" />
                        </div>
                        <div className="section">
                          <div className="event_title mt-30">
                            <h4>Test mohali</h4>
                          </div>
                          <div className="article border-b">
                            <p className="text1">hello </p>
                          </div>
                          <div className="coment-tag">
                            <div className="flex flex-wrap items-center mt-4">
                              <div className="w-1/2 xl:w-1/4 flex items-center">
                                <input id="box15" type="checkbox" />
                                <span className="ml-2">I will attend</span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <span className="comments event_comments">
                                  <i className="fa fa-comment-o"></i>{" "}
                                  <span className="comment_text" id="comments">
                                    Comments (0)
                                  </span>
                                </span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <span className=" view_details_heading">
                                  <i
                                    className="fa fa-info"
                                    aria-hidden="true"
                                  ></i>
                                  <span className="view_detail">
                                    View Details
                                  </span>
                                </span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <div className="reports-sec">
                                  <span className="view_details_heading">
                                    <i className="material-icons">
                                      error_outline
                                    </i>{" "}
                                    <span>Report</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="events_row  mt-10">
                    <div className="event_col">
                      <div className="event_body border shadow">
                        <span className="event-tag-wall">Event</span>
                        <div className="event_image">
                          <div className="event_date d-flex flex-column align-items-center justify-content-center">
                            <div className="event_day">05</div>
                            <div className="event_month">Aug</div>
                          </div>
                        </div>
                        <div className="section">
                          <div className="event_title mt-30">
                            <h4>Festival Events</h4>
                          </div>
                          <div className="article border-b">
                            <p className="text1">Demo Festival event </p>
                          </div>
                          <div className="coment-tag">
                            <div className="flex flex-wrap items-center mt-4">
                              <div className="w-1/2 xl:w-1/4 flex items-center">
                                <input id="box15" type="checkbox" />
                                <span className="ml-2">I will attend</span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <span className="comments event_comments">
                                  <i className="fa fa-comment-o"></i>{" "}
                                  <span className="comment_text" id="comments">
                                    Comments (0)
                                  </span>
                                </span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <span className=" view_details_heading">
                                  <i
                                    className="fa fa-info"
                                    aria-hidden="true"
                                  ></i>
                                  <span className="view_detail">
                                    View Details
                                  </span>
                                </span>
                              </div>
                              <div className="w-1/2 xl:w-1/4">
                                <div className="reports-sec">
                                  <span className="view_details_heading">
                                    <i className="material-icons">
                                      error_outline
                                    </i>{" "}
                                    <span>Report</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="md:w-2/6  w-full">
                  <div className="card eventright_sidebar" id="sticky">
                    <div className="card-header">
                      <h5 className="text-xl font-semibold text-gray-800 p-4">
                        Quick Links
                      </h5>
                    </div>
                    <div className="card-body">
                      <ul className="rightnav">
                        <li className="nav-item">
                          <Link
                            className="nav-link flex py-3 px-3 border-b text-gray-500 hover:bg-gray-700 hover:text-white rounded"
                            to="/profile"
                          >
                            <i className="material-icons mr-2">person</i>
                            <p> My Profile </p>
                          </Link>
                        </li>
                        <li className="nav-item">
                          <Link
                            className="nav-link flex py-3 px-3 border-b text-gray-500 hover:bg-gray-700 hover:text-white rounded"
                            to="/calendar"
                          >
                            <i className="material-icons mr-2">
                              calendar_today
                            </i>
                            <p>My Calendar</p>
                          </Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
}

export default Wall;
