import React from "react";
import "./Sidebar.css";
import { NavLink } from "react-router-dom";
import $ from "jquery";
import Logo from "../../src/assets/images/logo.png";
import DefaultIcon from "../../src/assets/images/default-icon.png";

class Sidebar extends React.Component {
  render() {
    const dropDown = () => {
      $(".closed").stop().slideToggle(280);
      $("#dropdown-btn").toggleClass("carerd");
    };

    return (
      <div className="sidebar">
        <div className="pad15p">
          <NavLink to="/">
            <img src={Logo} alt="Logo" width="100%" />
          </NavLink>
        </div>
        <div className="sidebar-wrapper h-screen overflow-x-auto relative">
          {/* For Students */}
          <ul className="flex flex-col mt-3 sideactive mx-3 ">
            <li className="userDeatails mb-2 px-3 py-4">
              <div
                id="dropdown-btn"
                className="text-white flex items-center justify-between cursor-pointer dropdown"
                onClick={() => dropDown()}
              >
                <div className="flex flex-wrap items-center">
                  <img src={DefaultIcon} alt="" className="rounded-full w-8" />
                  <span className="pl-2 text-sm">Miguel Cantu</span>
                </div>
                <i className="fa fa-caret-down"></i>
              </div>
              <div
                id="dropdown-container"
                className="closed text-white pt-4 text-sm"
              >
                <NavLink
                  to="/profile"
                  className="py-2 pl-10 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                >
                  Profile
                </NavLink>
              </div>
            </li>
            <li className=" mb-2">
              <NavLink
                className="py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/calender"
              >
                <i className="material-icons mr-4">calendar_today</i>
                <span className="text-sm"> Calendar </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                exact
                to="/"
              >
                <i className="material-icons mr-4">collections</i>
                <span className="text-sm"> Wall </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/checkitout"
              >
                <i className="material-icons mr-4">add_photo_alternate</i>
                <span className="text-sm"> Check It Out </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/contests"
              >
                <i className="material-icons mr-4">emoji_events</i>
                <span className="text-sm"> Contests </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/chat"
              >
                <i className="material-icons mr-4">chat</i>
                <span className="text-sm"> Chat </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/courses"
              >
                <i className="material-icons mr-4">import_contacts</i>
                <span className="text-sm"> Courses </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/gallery"
              >
                <i className="material-icons mr-4">image</i>
                <span className="text-sm"> Gallery </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/feedback"
              >
                <i className="material-icons mr-4">feedback</i>
                <span className="text-sm"> Feedback </span>
              </NavLink>
            </li>
            <div className="inMobileShow">
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/profile"
                >
                  <i className="material-icons mr-4">settings</i>
                  <span className="text-sm"> Settings </span>
                </NavLink>
              </li>
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/checkitout"
                >
                  <i className="material-icons mr-4">code</i>
                  <span className="text-sm"> Forgot Code </span>
                </NavLink>
              </li>
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/"
                >
                  <i className="material-icons mr-4">power_settings_new</i>
                  <span className="text-sm"> Logout </span>
                </NavLink>
              </li>
            </div>
          </ul>
          {/* End Of Students */}

          {/* For Teacher */}
          {/* <ul className="flex flex-col mt-3 sideactive mx-3 ">
            <li className="userDeatails mb-2 px-3 py-4">
              <div
                id="dropdown-btn"
                className="text-white flex items-center justify-between cursor-pointer dropdown"
                onClick={() => dropDown()}
              >
                <div className="flex flex-wrap items-center">
                  <img src={DefaultIcon} alt="" className="rounded-full w-8" />
                  <span className="pl-2 text-sm">Teacher</span>
                </div>
                <i className="fa fa-caret-down"></i>
              </div>
              <div
                id="dropdown-container"
                className="closed text-white pt-4 text-sm"
              >
                <NavLink
                  to="/profile"
                  className="py-2 pl-10 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                >
                  Profile
                </NavLink>
              </div>
            </li>

            <li className=" mb-2">
              <NavLink
                className="py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/"
              >
                <i className="material-icons mr-4">dashboard</i>
                <span className="text-sm"> Dashboard </span>
              </NavLink>
            </li>

            <li className=" mb-2">
              <NavLink
                className="py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/calendar"
              >
                <i className="material-icons mr-4">calendar_today</i>
                <span className="text-sm"> Calendar </span>
              </NavLink>
            </li>

            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/courses"
              >
                <i className="material-icons mr-4">import_contacts</i>
                <span className="text-sm"> Courses </span>
              </NavLink>
            </li>

            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/"
                exact
              >
                <i className="material-icons mr-4">collections</i>
                <span className="text-sm"> Wall </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/checkitout"
              >
                <i className="material-icons mr-4">add_photo_alternate</i>
                <span className="text-sm"> Check It Out </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/contests"
              >
                <i className="material-icons mr-4">emoji_events</i>
                <span className="text-sm"> Contests </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/chat"
              >
                <i className="material-icons mr-4">chat</i>
                <span className="text-sm"> Chat </span>
              </NavLink>
            </li>

            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/gallery"
              >
                <i className="material-icons mr-4">image</i>
                <span className="text-sm"> Gallery </span>
              </NavLink>
            </li>
            <li className=" mb-2">
              <NavLink
                className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                to="/feedback"
              >
                <i className="material-icons mr-4">feedback</i>
                <span className="text-sm"> Feedback </span>
              </NavLink>
            </li>
            <div className="inMobileShow">
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/profile"
                >
                  <i className="material-icons mr-4">settings</i>
                  <span className="text-sm"> Settings </span>
                </NavLink>
              </li>
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/checkitout"
                >
                  <i className="material-icons mr-4">code</i>
                  <span className="text-sm"> Forgot Code </span>
                </NavLink>
              </li>
              <li className=" mb-2">
                <NavLink
                  className=" py-2 hover:bg-gray-700 rounded transition ease-in duration-200 text-white flex items-center px-3"
                  to="/"
                >
                  <i className="material-icons mr-4">power_settings_new</i>
                  <span className="text-sm"> Logout </span>
                </NavLink>
              </li>
            </div>
          </ul> */}
          {/* End Of Teacher */}

          <div className="copyright-sidebar bgColor ml-2 px-5 border-t border-gray-700 left-0 text-white text-xs text-center py-4 xl:fixed lg:fixed md:relative bottom-0">
            Copyright ©<script>document.write(new Date().getFullYear())</script>
            2020 . All Rights Reserved.
          </div>
        </div>
      </div>
    );
  }
}

export default Sidebar;
