import React from "react";
import { Link } from "react-router-dom";

class DropDownHeader extends React.Component {
  constructor() {
    super();

    this.handleClick = this.handleClick.bind(this);
    this.handleOutsideClick = this.handleOutsideClick.bind(this);

    this.state = {
      dropDown: false,
    };
  }

  handleClick() {
    if (!this.state.dropDown) {
      // attach/remove event handler
      document.addEventListener("click", this.handleOutsideClick, false);
    } else {
      document.removeEventListener("click", this.handleOutsideClick, false);
    }

    this.setState((prevState) => ({
      dropDown: !prevState.dropDown,
    }));
  }

  handleOutsideClick(e) {
    // ignore clicks on the component itself
    if (this.node.contains(e.target)) {
      return;
    }

    this.handleClick();
  }

  render() {
    return (
      <ul
        className="flex flex-col lg:flex-row list-none lg:ml-auto"
        ref={(node) => {
          this.node = node;
        }}
      >
        <li className="nav-item">
          <div className="px-3 py-2 flex items-center text-xs uppercase font-bold leading-snug text-white hover:opacity-75">
            <i
              className="material-icons cursor-pointer"
              style={{ fontSize: "20px" }}
              onClick={this.handleClick}
            >
              settings
            </i>
          </div>

          {this.state.dropDown && (
            <div className="text-white posFix">
              <ul
                className="block dropUl bg-white w-10/12 text-base z-50 border float-left py-2 list-none text-left rounded shadow-xl mt-1"
                x-placement="bottom-start"
              >
                <li className="px-2 border-b">
                  <Link
                    to="/profile"
                    className="text-sm hover:shadow-lg rounded mb-2 py-2 pl-3 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
                  >
                    Settings
                  </Link>
                </li>
                <li className="px-2 border-b">
                  <Link
                    to="/profile"
                    className="text-sm hover:shadow-lg mt-2 rounded mb-2 py-2 pl-3 font-normal block w-full whitespace-no-wrap bg-transparent  text-gray-800"
                  >
                    Forgot Code
                  </Link>
                </li>
                <li className="px-2">
                  <Link
                    to="/"
                    className="text-sm hover:shadow-lg mt-2 font-normal rounded pl-3 py-2 block w-full whitespace-no-wrap bg-transparent  text-gray-800"
                  >
                    Logout
                  </Link>
                </li>
              </ul>
            </div>
          )}
        </li>
      </ul>
    );
  }
}

export default DropDownHeader;
