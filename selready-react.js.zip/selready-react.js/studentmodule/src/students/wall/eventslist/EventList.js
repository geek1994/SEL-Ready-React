import React from "react";
import "./EventList.css";

class EventList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      comment: false,
      viewDeatils: false,
      report: false,
    };
  }

  togglefn() {
    this.setState({
      comment: !this.state.comment,
      report: false,
    });
  }

  togglefn1() {
    this.setState({
      report: !this.state.report,
      comment: false,
    });
  }

  render() {
    return (
      <div className="eventSec shadow-md border mt-5 relative">
        <span className="greenC">Spotlight</span>

        <div className="pt-6 pb-5 px-5">
          <div className="flex flex-wrap -mx-1">
            <div className="my-1 px-1 lg:pl-0 xl:w-4/12 lg:w-4/12 sm:w-4/12 w-full">
              <div className="eventImage">
                <img
                  src="https://demo.selready.com/admin/assets/img/faces/default-user-img.jpg"
                  alt=""
                  className="xl:w-40 md:w-40 sm:w-40 w-full"
                />
              </div>
            </div>

            <div className="my-1 px-1 lg:pl-0 xl:w-8/12 lg:w-8/12 sm:w-8/12 w-full">
              <h2 className="text-2xl font-medium border-b border-gray-400 pb-3">
                Abc Abc
              </h2>
              <table className="table-auto">
                <tbody>
                  <tr>
                    <td className="px-4 py-2 font-bold">Institute</td>
                    <td className="pl-20 py-2">Fdgsfdsdfas</td>
                  </tr>
                  <tr className="bg-gray-100">
                    <td className="px-4 py-2 font-bold">Grade</td>
                    <td className="pl-20 py-2">10th</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div className="border-t mt-6 pt-3 flex justify-between">
            <span
              className="comments text-sm text-gray-600 cursor-pointer"
              onClick={() => this.togglefn()}
            >
              <i
                className="fa fa-comment-o pr-1"
                style={{ fontSize: "16px" }}
              ></i>
              <span>Comments (0)</span>
            </span>

            <span
              className="comments text-sm text-gray-600  flex items-center cursor-pointer"
              onClick={() => this.togglefn1()}
            >
              <i className="material-icons mr-1" style={{ fontSize: "22px" }}>
                error_outline
              </i>
              <span>Report</span>
            </span>
          </div>
          <div>
            {this.state.comment ? (
              <>
                <h3 className="mt-5 border-b border-gray-400 pb-1 inline-block">
                  Comments
                </h3>
                <form>
                  <div className="w-full mt-4">
                    <textarea
                      placeholder="write a comment"
                      className="resize h-20 placeholder-opacity-100 border rounded border-gray-400 p-2 px-3 text-sm w-full focus:outline-none"
                    ></textarea>
                  </div>
                  <div className="text-right">
                    <button className="transition duration-300 ease-in-out btnIinfo mt-4 hover:opacity-75 text-white font-normal py-2 px-4 rounded">
                      Post
                    </button>
                  </div>
                  <div className="border-t mt-5">
                    {/* <div
                      className="orangeColor text-white border mt-2 px-4 py-3 rounded relative"
                      role="alert"
                    >
                      There is no comment yet
                    </div> */}
                    <div className="media-list mt-4">
                      <ul>
                        <li>
                          <div className="flex">
                            <div
                              className="mr-3
                          "
                            >
                              <img
                                src="https://demo.selready.com/admin/assets/img/default-icon.png"
                                alt=""
                                className="border rounded-full w-12"
                              />
                            </div>
                            <div className="border w-full py-2 rounded-r-lg px-2 bg-green-100 rounded-b-lg border-gray-400">
                              <h2 className="border-b flex justify-between items-center text-md pb-2 font-bold text-green-500">
                                Super Admin
                                <small className="text-gray-700 font-normal">
                                  1 week ago
                                </small>
                              </h2>
                              <p className="text-sm pt-2">Welcome</p>
                            </div>
                          </div>
                          <p className="text-right text-sm">
                            <span className="reply text-gray-600 cursor-pointer">
                              <i className="fa fa-reply mr-1"></i>
                              Reply
                            </span>
                          </p>
                          {/* Please add Form here removed bcz showing error in Console */}
                          <div className="replyForm flex justify-end">
                            <div className="w-11/12 mt-4">
                              <textarea
                                placeholder="Comment"
                                className="resize h-20 placeholder-opacity-100 border rounded border-gray-400 p-2 px-3 text-sm w-full focus:outline-none"
                              ></textarea>
                              <div className="text-right">
                                <button className="transition duration-300 ease-in-out bgRed  mt-2 hover:opacity-75 text-white font-normal py-2 px-4 mr-2 rounded">
                                  Cancel
                                </button>
                                <button className="transition duration-300 ease-in-out btnIinfo mt-2 hover:opacity-75 text-white font-normal py-2 px-4 rounded">
                                  Post
                                </button>
                              </div>
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </form>
              </>
            ) : null}
          </div>
          {this.state.report ? (
            <>
              <div className="relative mt-2">
                <div className="reportBody z-10  absolute border-gray-400 border bg-white p-2 rounded-md right-0">
                  <div className="relative">
                    <select
                      className="block appearance-none text-sm w-full bg-white border border-gray-400 shadow-md text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                      id="grid-state"
                    >
                      <option>Violation of someone's privacy</option>
                      <option>Fraud and spam</option>
                      <option>Violence</option>
                      <option>Harassment</option>
                      <option>False News</option>
                      <option>Unauthorized sales</option>
                      <option>Hate speech</option>
                      <option>Terrorism</option>
                      <option>Gross Content</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                      <svg
                        className="fill-current h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 20 20"
                      >
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                      </svg>
                    </div>
                  </div>
                  <button className="transition duration-300 ease-in-out bgRed mt-4 hover:opacity-75 text-white font-normal py-2 text-sm px-4 rounded">
                    Submit
                  </button>
                </div>
              </div>
            </>
          ) : null}
        </div>
      </div>
    );
  }
}

export default EventList;
