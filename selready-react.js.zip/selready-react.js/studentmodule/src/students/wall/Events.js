import React from "react";
import "./Events.css";
import EventList from "./eventslist/EventList";
import { Link } from "react-router-dom";
import $ from "jquery";

class Events extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      comment: false,
      viewDeatils: false,
      report: false,
    };
  }

  togglefn() {
    this.setState({
      comment: !this.state.comment,
      viewDeatils: false,
      report: false,
    });
  }

  togglefn1() {
    this.setState({
      viewDeatils: !this.state.viewDeatils,
      comment: false,
      report: false,
    });
  }

  togglefn2() {
    this.setState({
      report: !this.state.report,
      comment: false,
      viewDeatils: false,
    });
  }

  componentDidMount() {
    document.title = "Wall";
  }

  render() {
    $(window).scroll(function () {
      var scroll = $(window).scrollTop();
      if (scroll >= 180) {
        $("#sticky").addClass("sticky");
      } else {
        $("#sticky").removeClass("sticky");
      }
    });

    return (
      <>
        <div className="flex flex-wrap">
          <div className="my-1 px-1 xl:w-8/12 lg:w-2/3 md:w-full w-full">
            <div className="flex justify-between items-center py-2 md:px-6 px-2 shadow-md">
              <h1 className="text-xl font-normal">Latest Updates</h1>
              <div className="relative w-4/12">
                <select
                  className="block appearance-none text-sm w-full bg-white border border-gray-400 shadow-md text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                  id="grid-state"
                >
                  <option>All</option>
                  <option>Events</option>
                  <option>Spotlight</option>
                  <option>Check It Out</option>
                  <option>Contest</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                  <svg
                    className="fill-current h-4 w-4"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                  </svg>
                </div>
              </div>
            </div>
            <div className="eventSec shadow-md border mt-5 relative">
              <span className="checkit">Check It Out</span>
              <video width="100%" height="240" controls>
                <source src="https://youtu.be/gC_L9qAHVJ8" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <div className="pt-6 pb-5 md:px-5 px-2">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-medium">30 minute</h3>
                  <p className="text-sm font-normal ">
                    <span className="font-medium"> Posted By : </span>
                    <span className="text-gray-700">Cam Stuart</span>
                  </p>
                </div>
                <div className="border-t mt-6 pt-3 flex justify-between">
                  <span
                    className="comments text-sm text-gray-600 cursor-pointer"
                    onClick={() => this.togglefn()}
                  >
                    <i
                      className="fa fa-comment-o pr-1"
                      style={{ fontSize: "16px" }}
                    ></i>
                    <span>Comments (0)</span>
                  </span>
                  <span
                    className="comments text-sm text-gray-600 cursor-pointer"
                    onClick={() => this.togglefn1()}
                  >
                    <i
                      className="fa fa-info w-4 text-center line-h leading-4 h-4 mr-1 border rounded-full border-gray-600"
                      style={{ fontSize: "12px" }}
                    ></i>
                    <span>View Details</span>
                  </span>
                  <span
                    className="comments text-sm text-gray-600  flex items-center cursor-pointer"
                    onClick={() => this.togglefn2()}
                  >
                    <i
                      className="material-icons mr-1"
                      style={{ fontSize: "22px" }}
                    >
                      error_outline
                    </i>
                    <span>Report</span>
                  </span>
                </div>
                <div>
                  {this.state.comment ? (
                    <>
                      <h3 className="mt-5 border-b border-gray-400 pb-1 inline-block">
                        Comments
                      </h3>
                      <form>
                        <div className="w-full mt-4">
                          <textarea
                            placeholder="write a comment"
                            className="resize h-20 placeholder-opacity-100 border rounded border-gray-400 p-2 px-3 text-sm w-full focus:outline-none"
                          ></textarea>
                        </div>
                        <div className="text-right">
                          <button className="transition duration-300 ease-in-out btnIinfo mt-4 hover:opacity-75 text-white font-normal py-2 px-4 rounded">
                            Post
                          </button>
                        </div>
                        <div className="border-t mt-5">
                          <div
                            className="orangeColor text-white border mt-2 px-4 py-3 rounded relative"
                            role="alert"
                          >
                            There is no comment yet
                          </div>
                        </div>
                      </form>
                    </>
                  ) : null}

                  {this.state.viewDeatils ? (
                    <>
                      <h3 className="mt-5 text-2xl font-medium pb-1 inline-block">
                        Description
                      </h3>
                      <p className="text-sm text-gray-600">
                        30 minute fat burning home workout for beginners.
                        Achievable, low impact results.
                      </p>
                    </>
                  ) : null}
                </div>
                {this.state.report ? (
                  <>
                    <div className="relative mt-2">
                      <div className="reportBody z-10 absolute border-gray-400 border bg-white p-2 rounded-md right-0">
                        <div className="relative">
                          <select
                            className="block appearance-none text-sm w-full bg-white border border-gray-400 shadow-md text-gray-700 py-3 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                            id="grid-state"
                          >
                            <option>Violation of someone's privacy</option>
                            <option>Fraud and spam</option>
                            <option>Violence</option>
                            <option>Harassment</option>
                            <option>False News</option>
                            <option>Unauthorized sales</option>
                            <option>Hate speech</option>
                            <option>Terrorism</option>
                            <option>Gross Content</option>
                          </select>
                          <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                            <svg
                              className="fill-current h-4 w-4"
                              xmlns="http://www.w3.org/2000/svg"
                              viewBox="0 0 20 20"
                            >
                              <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                            </svg>
                          </div>
                        </div>
                        <button className="transition duration-300 ease-in-out bgRed mt-4 hover:opacity-75 text-white font-normal py-2 text-sm px-4 rounded">
                          Submit
                        </button>
                      </div>
                    </div>
                  </>
                ) : null}
              </div>
            </div>
            <EventList />
            <EventList />
          </div>

          <div
            className="my-1 px-1 xl:w-4/12 lg:w-4/12 md:w-full w-full"
            id="sticky"
          >
            <div
              className="w-full md:ml-0 lg:mt-8 xl:pl-16 xl:pr-2 lg:ml-0"
              id="navbar"
            >
              <div className="px-6 pt-4 pb-8 shadow-lg rounded border">
                <div className="font-bold text-xl mb-4">Quick Links</div>
                <ul className="block bg-white text-base z-50 py-2 list-none mt-1">
                  <li className="border-b">
                    <Link
                      className="text-sm flex items-center rounded py-3 hover:bg-gray-600 hover:text-white font-normal w-full whitespace-no-wrap bg-transparent pl-2 text-gray-800"
                      to="/profile"
                    >
                      <i className="material-icons mr-1">person</i> My Profile
                    </Link>
                  </li>
                  <li className="border-b">
                    <Link
                      className="text-sm flex items-center pl-2 rounded  hover:text-white py-3 hover:bg-gray-600 font-normal w-full whitespace-no-wrap bg-transparent  text-gray-800"
                      to="/calender"
                    >
                      <i className="material-icons mr-1">calendar_today</i> My
                      Calendar
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Events;
