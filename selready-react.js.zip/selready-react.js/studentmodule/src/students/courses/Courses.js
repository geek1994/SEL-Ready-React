import React from "react";
import { Link } from "react-router-dom";
import CommonHeader from "../commonheader/CommonHeader";

class Courses extends React.Component {
  constructor() {
    super();
    this.state = {
      courses: [
        {
          id: 1,
          title: "Test course",
          para:
            "This needs to be a 100 characters long so it has a sufficient amount of words to describe what the course is about.",
        },
        {
          id: 2,
          title: "Test course 1",
          para:
            "This needs to be a 100 characters long so it has a sufficient amount of words to describe what the course is about.",
        },
      ],
    };
  }

  componentDidMount() {
    document.title = "Courses";
  }

  render() {
    return (
      <div className="rounded shadow-lg border mt-8">
        <div className="xl:px-6 lg:px-6 md:px-3 px-1 py-2 pb-5">
          <div className="flex justify-between items-center mb-5 relative">
            <CommonHeader icon="class" name="Courses" />
          </div>

          <section className="text-gray-700">
            <div className="container mx-auto">
              <div className="flex flex-wrap -m-4">
                {this.state.courses
                  ? this.state.courses.map((course) => {
                      return (
                        <div
                          className="p-4 md:w-1/2 xl:w-1/4 lg:w-1/3"
                          key={course.id}
                        >
                          <div className="h-full border border-gray-400 rounded-lg overflow-hidden">
                            <Link to={`/lessons`}>
                              <h1 className="title-font p-3 border-b border-gray-400 text-md font-medium text-gray-900">
                                {course.title}
                              </h1>
                              <p className="leading-relaxed bg-orange-100 text-sm font-medium text-justify italic mb-3 py-3 px-3">
                                {course.para}
                              </p>
                              <br />

                              <br />
                            </Link>
                          </div>
                        </div>
                      );
                    })
                  : null}
              </div>
            </div>
          </section>
        </div>
      </div>
    );
  }
}

export default Courses;
