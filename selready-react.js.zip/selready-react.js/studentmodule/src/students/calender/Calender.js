import React from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import "./Calender.css";

class Calender extends React.Component {
  componentDidMount() {
    document.title = "Calender";
  }
  render() {
    return (
      <>
        <FullCalendar plugins={[dayGridPlugin]} initialView="dayGridMonth" />
      </>
    );
  }
}

export default Calender;
