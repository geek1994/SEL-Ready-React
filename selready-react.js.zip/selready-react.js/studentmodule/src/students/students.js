import React from "react";
import { Route } from "react-router-dom";
import Events from "../students/wall/Events";
import Calender from "../students/calender/Calender";
import Checkitout from "../students/checkitout/Checkitout";
import AddCheckitOut from "../students/checkitout/add/AddCheckitOut";
import Contests from "../students/contests/Contests";
import Courses from "../students/courses/Courses";
import Lessons from "../students/courses/lessons/Lessons";
import Gallery from "../students/gallery/Gallery";
import Feedback from "../students/feedback/Feedback";
import Chat from "../students/chat/Chat";
import Profile from "../students/profile/Profile";

const Students = () => {
  return (
    <>
      <Route path="/" exact component={Events} />
      <Route path="/profile" exact component={Profile} />
      <Route path="/calender" component={Calender} />
      <Route path="/checkitout" component={Checkitout} />
      <Route path="/addcheckitout" component={AddCheckitOut} />
      <Route path="/contests" component={Contests} />
      <Route path="/courses" component={Courses} />
      <Route path="/lessons" component={Lessons} />
      <Route path="/chat" component={Chat} />
      <Route path="/gallery" component={Gallery} />
      <Route path="/feedback" component={Feedback} />
    </>
  );
};

export default Students;
