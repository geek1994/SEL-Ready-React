import React from "react";
import Sidebar from "./sidebar/Sidebar";
import { BrowserRouter as Router, Switch, Redirect } from "react-router-dom";
import Header from "./students/header/Header";
import "./assets/css/font-awesome.min.css";
import "./assets/css/main.css";
import Students from "./students/students";
// import Admin from "./admin/Admin";

function App() {
  return (
    <>
      <Router>
        <div className="" id="wrapper">
          <Sidebar />
          <div className="rightside">
            <Header />
            <div className="py-6 xl:pl-5 lg:pl-0 md:mx-3 mx-2">
              <Switch>
                <Students />
                {/* <Admin /> */}
                <Redirect to="/" />
              </Switch>
            </div>
          </div>
        </div>
      </Router>
    </>
  );
}

export default App;
